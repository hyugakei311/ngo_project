from django.apps import AppConfig

import os


class NgoConfig(AppConfig):
    name = 'ngo'
